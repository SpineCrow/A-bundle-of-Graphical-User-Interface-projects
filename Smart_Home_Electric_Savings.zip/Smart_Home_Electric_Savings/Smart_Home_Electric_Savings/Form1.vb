﻿Public Class Form1

    ' Declare lists to hold month and savings data
    Dim monthList As New List(Of String)
    Dim savingsList As New List(Of Double)

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Clear any existing items and data
        ComboBox1.Items.Clear()
        monthList.Clear()
        savingsList.Clear()

        ' Read all lines from the file
        Dim lines() As String = IO.File.ReadAllLines("Savings.txt")

        ' Process pairs of lines: month, then value
        Dim i As Integer = 0
        While i < lines.Length - 1
            Dim month As String = lines(i).Trim()
            Dim savingsStr As String = lines(i + 1).Trim()
            Dim savings As Double

            If Double.TryParse(savingsStr, savings) Then
                monthList.Add(month)
                savingsList.Add(savings)
            End If

            i += 2 ' Move to next pair
        End While

        ' Populate ComboBox with months
        ComboBox1.Items.Clear()
        ComboBox1.Items.AddRange(monthList.ToArray())
    End Sub

    Private Sub cmbMonths_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Label3.Text = ""
        Label4.Text = ""
        Dim index As Integer = ComboBox1.SelectedIndex
        If index >= 0 AndAlso index < savingsList.Count Then
            Dim selectedMonth As String = monthList(index)
            Dim savings As Double = savingsList(index)
            Label2.Text = $"The electric savings for {selectedMonth} is ${savings:F2}"
        End If
    End Sub

    Private Sub btnDisplayStats_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If savingsList.Count > 0 Then
            Dim average As Double = savingsList.Average()
            Dim maxValue As Double = savingsList.Max()
            Dim maxIndex As Integer = savingsList.IndexOf(maxValue)
            Dim maxMonth As String = monthList(maxIndex)

            Label3.Text = $"The average monthly savings: ${average:F2}"
            Label4.Text = $"{maxMonth:F2} had the most significant monthly savings"

        End If
    End Sub
End Class
