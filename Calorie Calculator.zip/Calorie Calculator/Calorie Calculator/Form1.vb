﻿Imports System.IO
' ****************************************
' Student: Landon Alexander III
' Project: Capstone Project - Calorie Calculator
' Class: Graph User Interface Dev
' Description: This form focuses on calculating the total amount of calories you 
' Consumed based on your choice of food from the list.
' ****************************************************

Public Class Form1
    ' Declare lists to hold food data
    Dim foodNameList As New List(Of String)
    Dim portionList As New List(Of String)
    Dim calorieList As New List(Of Integer)

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Clears existing data in all lists
        foodNameList.Clear()
        portionList.Clear()
        calorieList.Clear()
        ListBox1.Items.Clear()

        ' Read all lines from the file in triplets
        Dim lines() As String = IO.File.ReadAllLines("food_data.txt")

        ' Process triplets of lines: name, portion, then calories
        ' This is a loop that processes three lines (name, portion, calories)
        ' Until the file is about to end
        Dim i As Integer = 0
        While i < lines.Length - 2
            ' Extracts and cleans each piece of data from the triplet
            Dim foodName As String = lines(i).Trim()
            Dim portion As String = lines(i + 1).Trim()
            Dim caloriesStr As String = lines(i + 2).Trim()
            Dim calories As Integer ' Converts calorie string to integer

            ' Adds entries to their respective lists
            If Integer.TryParse(caloriesStr, calories) Then
                foodNameList.Add(foodName)
                portionList.Add(portion)
                calorieList.Add(calories)

                ' Add to ListBox1 display
                ListBox1.Items.Add($"{foodName} ({portion}) - {calories} cal")
            End If

            i += 3 ' Moves to next triplet in file
        End While
    End Sub

    ' Example search function
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Gets and sanitizes the user input (removes the spaces, and converts it ot lowercase)
        Dim searchTerm = TextBox1.Text.Trim.ToLower
        ListBox1.Items.Clear()

        ' Uses case-insensitive search to look through all the names
        For i = 0 To foodNameList.Count - 1
            If foodNameList(i).ToLower.Contains(searchTerm) Then
                ListBox1.Items.Add($"{foodNameList(i)} ({portionList(i)}) - {calorieList(i)} cal")
            End If
        Next
    End Sub

    ' Tracks consumed food, and runs the total calorie total
    Dim dailyFoodLog As New List(Of String)
    Dim dailyCalories As Integer = 0

    Private Sub btnAddToLog_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' Verifies an item is selected
        If ListBox1.SelectedIndex >= 0 Then
            Dim index As Integer = ListBox1.SelectedIndex
            ' Stores and format it in pipe-delimited format (Apple|1 medium|95)
            dailyFoodLog.Add($"{foodNameList(index)}|{portionList(index)}|{calorieList(index)}")
            ' Updates the total calorie amount
            dailyCalories += calorieList(index)

            ' Update display
            ListBox2.Items.Add(ListBox1.SelectedItem.ToString())
            Label4.Text = $"Total: {dailyCalories} calories"

            ' Save to file
            File.WriteAllLines("daily_log.txt", dailyFoodLog)
        End If
    End Sub


    ' Clear Button click event
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles Button1.Click
        dailyFoodLog.Clear()
        dailyCalories = 0
        ListBox2.Items.Clear()
        Label4.Text = "Total: 0 calories"
        TextBox1.Text = ""
        ListBox1.Items.Clear()
        Label3.Text = ""
        TextBox1.Focus()
    End Sub

End Class
