﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        TextBox1 = New TextBox()
        ListBox1 = New ListBox()
        Label2 = New Label()
        Button1 = New Button()
        Button2 = New Button()
        Label3 = New Label()
        Button3 = New Button()
        ListBox2 = New ListBox()
        Label4 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 16F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(438, 25)
        Label1.Name = "Label1"
        Label1.Size = New Size(285, 45)
        Label1.TabIndex = 0
        Label1.Text = "Calorie Calculator"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(12, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(326, 221)
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(496, 175)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(150, 31)
        TextBox1.TabIndex = 2
        ' 
        ' ListBox1
        ' 
        ListBox1.BackColor = Color.MistyRose
        ListBox1.FormattingEnabled = True
        ListBox1.ItemHeight = 25
        ListBox1.Location = New Point(389, 227)
        ListBox1.Name = "ListBox1"
        ListBox1.Size = New Size(378, 79)
        ListBox1.TabIndex = 3
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 14F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(444, 75)
        Label2.Name = "Label2"
        Label2.Size = New Size(268, 76)
        Label2.TabIndex = 4
        Label2.Text = "Enter here to search " & vbCrLf & "    for your food"
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.MistyRose
        Button1.Location = New Point(89, 386)
        Button1.Name = "Button1"
        Button1.Size = New Size(160, 51)
        Button1.TabIndex = 5
        Button1.Text = "Clear"
        Button1.UseVisualStyleBackColor = False
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.MistyRose
        Button2.Location = New Point(89, 260)
        Button2.Name = "Button2"
        Button2.Size = New Size(160, 57)
        Button2.TabIndex = 6
        Button2.Text = "Search"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Location = New Point(438, 126)
        Label3.Name = "Label3"
        Label3.Size = New Size(0, 25)
        Label3.TabIndex = 7
        ' 
        ' Button3
        ' 
        Button3.BackColor = Color.MistyRose
        Button3.Location = New Point(89, 323)
        Button3.Name = "Button3"
        Button3.Size = New Size(160, 57)
        Button3.TabIndex = 9
        Button3.Text = "Add to Daily Log"
        Button3.UseVisualStyleBackColor = False
        ' 
        ' ListBox2
        ' 
        ListBox2.BackColor = Color.MistyRose
        ListBox2.FormattingEnabled = True
        ListBox2.ItemHeight = 25
        ListBox2.Location = New Point(389, 323)
        ListBox2.Name = "ListBox2"
        ListBox2.Size = New Size(378, 79)
        ListBox2.TabIndex = 10
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 14F, FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(340, 427)
        Label4.Name = "Label4"
        Label4.Size = New Size(183, 38)
        Label4.TabIndex = 11
        Label4.Text = "Total Calories"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(10F, 25F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Salmon
        ClientSize = New Size(800, 517)
        Controls.Add(Label4)
        Controls.Add(ListBox2)
        Controls.Add(Button3)
        Controls.Add(Label3)
        Controls.Add(Button2)
        Controls.Add(Button1)
        Controls.Add(Label2)
        Controls.Add(ListBox1)
        Controls.Add(TextBox1)
        Controls.Add(PictureBox1)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Calorie Calculator"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Button3 As Button
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents Label4 As Label

End Class
