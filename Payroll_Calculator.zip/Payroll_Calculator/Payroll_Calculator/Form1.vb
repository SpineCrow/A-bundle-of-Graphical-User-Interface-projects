﻿Imports System.Reflection.Emit
' ****************************************
' Student: Landon Alexander III
' Project: Payroll Calculator GUI Development Project
' Clas:s Graph User Interface Dev
' Description: This form focuses on calculating the gross pay for HR personnel, and 
' deduces the net income to different categories.
' ****************************************************
Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim strIncome As String
        Dim decIncome As Decimal
        Dim decFica As Decimal
        Dim decFederal As Decimal
        Dim decState As Decimal
        Dim decNet As Decimal

        ' Declare constants for the tax rates
        Const cdecFica As Decimal = 0.0765D
        Const cdecFed As Decimal = 0.22D
        Const cdecState As Decimal = 0.04D

        ' Get the user input from TextBox1 and convert it to Decimal
        strIncome = TextBox1.Text
        If Not Decimal.TryParse(strIncome, decIncome) Then
            ' Display a message box if the input is not valid
            MessageBox.Show("Please enter a valid number for the Gross Pay.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error)

            ' Clear the TextBox and set focus for reentry
            TextBox1.Clear()
            TextBox1.Focus()
            Exit Sub
        End If

        ' Calculate the taxes
        decFica = decIncome * cdecFica
        decFederal = decIncome * cdecFed
        decState = decIncome * cdecState

        ' Calculate the net income
        decNet = decIncome - (decFica + decFederal + decState)

        ' Display the results on the labels (formatted as currency)
        Label9.Text = "" & decFica.ToString("C2")
        Label10.Text = "" & decFederal.ToString("C2")
        Label8.Text = "" & decState.ToString("C2")
        TextBox2.Text = "" & decNet.ToString("C2")

    End Sub


    ' ResetForm Method to reset the controls
    Private Sub ResetForm()
        Label8.Text = ""
        Label9.Text = ""
        Label10.Text = ""
        TextBox2.Text = ""

        ' Clear the TextBox for Gross Pay
        TextBox1.Clear()

        ' Set focus back to the TextBox
        TextBox1.Focus()
    End Sub


    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        ' Sends the calculations made from TextBox1 to the other labels
        Label8.Text = TextBox1.Text
        Label9.Text = TextBox1.Text
        Label10.Text = TextBox1.Text

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Resets all calculations made in the form
        ResetForm()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' Exits out the application made in runtime
        Application.Exit()
    End Sub

End Class
