﻿' ****************************************
' Student: Landon Alexander III
' Project: Catering Order GUI Development Project
' Class: Graph User Interface Dev
' Description: This form calculates platters chosen by the user, and pay it either with Pre-Pay,
' or with pay upon pickup. It calculates a discount based on the amount of loyalty points you have
' ****************************************************

Public Class Form1

    ' When the form loads, call the Button2_Click (Clear button logic) to initialize everything.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button2_Click(sender, e) ' Calls Clear button logic when the form loads
    End Sub

    ' Event to clear the form (called from the Clear button).
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Clear the loyalty points textbox and set focus
        TextBox1.Clear()
        TextBox1.Focus()

        ' Clear the payment info label
        Label4.Text = String.Empty

        ' Reset all radio buttons to default state
        RadioButton1.Checked = True ' Default platter choice (Gornet Cheese)
        RadioButton6.Checked = True ' Default payment method (Pre-Pay)
    End Sub

    ' Event to calculate the price and display payment information (called from the Calculate button).
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Initialize platter cost and loyalty points discount
        Dim platterCost As Decimal = 0.0D
        Dim loyaltyPointsDiscount As Decimal = 0.0D

        ' Determine the cost of the platter selected
        If RadioButton1.Checked Then
            platterCost = 49.99D ' Gornet Cheese price
        ElseIf RadioButton2.Checked Then
            platterCost = 59.99D ' Pinwheel Krape price
        ElseIf RadioButton3.Checked Then
            platterCost = 29.99D ' Veggie price
        ElseIf RadioButton4.Checked Then
            platterCost = 49.99D ' Sausage and Cheese price
        ElseIf RadioButton5.Checked Then
            platterCost = 29.99D ' Fruit price
        End If

        ' Check for valid loyalty points input
        If Decimal.TryParse(TextBox1.Text, loyaltyPointsDiscount) Then
            ' Validate that loyalty points are non-negative and less than platter cost
            If loyaltyPointsDiscount < 0 Then
                MessageBox.Show("Loyalty points cannot be negative.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBox1.Clear()
                TextBox1.Focus()
                Return
            ElseIf loyaltyPointsDiscount > platterCost Then
                MessageBox.Show("You cannot apply more loyalty points than the platter cost.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error)
                TextBox1.Clear()
                TextBox1.Focus()
                Return
            End If
        Else
            ' If the input is not a valid decimal, show an error message
            MessageBox.Show("Please enter a valid number for loyalty points.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error)
            TextBox1.Clear()
            TextBox1.Focus()
            Return
        End If

        ' Calculate the discount amount based on loyalty points
        Dim discountAmount As Decimal = loyaltyPointsDiscount
        ' Ensure the final price is not less than 0
        Dim finalPrice As Decimal = platterCost - discountAmount
        If finalPrice < 0 Then
            finalPrice = 0
        End If


        ' Format the payment information based on platter and payment method
        Dim paymentMethod As String = If(RadioButton6.Checked, "Pre-Pay", "Pay Upon Pickup") ' RadioButton6 is Pre-Pay, RadioButton7 is Pay Upon Pickup

        ' Display the payment information in the label
        Label4.Text = $"${finalPrice:F2}"
    End Sub

    ' Method to get the platter name based on the selected radio button
    Private Function GetPlatterName() As String
        If RadioButton1.Checked Then
            Return "Gornet Cheese"
        ElseIf RadioButton2.Checked Then
            Return "Pinwheel Krape"
        ElseIf RadioButton3.Checked Then
            Return "Veggie"
        ElseIf RadioButton4.Checked Then
            Return "Sausage and Cheese"
        ElseIf RadioButton5.Checked Then
            Return "Fruit"
        End If
        ' Default return if no platter is selected
        Return "Unknown Platter"
    End Function

    ' Event to handle changes in the selected platter (RadioButton1, RadioButton2, etc.)
    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged, RadioButton2.CheckedChanged, RadioButton3.CheckedChanged, RadioButton4.CheckedChanged, RadioButton5.CheckedChanged
        ' Logic to handle platter selection can be added here if necessary
    End Sub

    ' Event to handle changes in the payment method (RadioButton6 - Pre-Pay, RadioButton7 - Pay Upon Pickup)
    Private Sub RadioButton6_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton6.CheckedChanged, RadioButton7.CheckedChanged
        ' Logic to handle payment method changes can be added here if necessary
    End Sub

End Class
